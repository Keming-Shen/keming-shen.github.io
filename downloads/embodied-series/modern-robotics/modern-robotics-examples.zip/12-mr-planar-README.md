# 平面 2R：Modern Robotics 几何检查

依赖：Python 3 与 NumPy。运行不需要 Pinocchio、机器人仿真器或 GPU。

解压到一个目录，从该目录执行：

```bash
python 12-mr-planar-check.py
```

脚本检查两根 1 米连杆的正向运动学、空间 Jacobian 与末端位置有限差分，
并从 20°/70° 的初值恢复 30°/60° 的可达目标。通过检查时，程序打印
`IK success: True`，末端位置约为 `[0.866025404, 1.5, 0]` 米。

目录结构：

```text
12-mr-planar-check.py
modern_robotics/
  __init__.py
  core.py
  LICENSE
```

`modern_robotics/core.py` 是未修改的 NxRLab/ModernRobotics 配套代码，固定提交为
`cbd41fdf0bf75dbd5e986d832ae14226964ff0ac`，采用 MIT License，完整声明保留在
`modern_robotics/LICENSE`。`__init__.py` 只导出该文件的接口。2R 参数与检查为配套教学案例。

该包不包含教材 PDF、训练数据、机器人模型或预训练权重。
