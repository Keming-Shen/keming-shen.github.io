# MotionLCM V2 本地推理记录

这些动作来自官方预训练 MotionLCM V2 HumanML3D 检查点，固定源码版本
`81c06368c17b056713deef2e9f6483f3172eea42`，并非随机初始化或手工关键帧。
原始动作包含两个 100 帧、20 fps 的样本；提示文本、种子、检查点哈希、
硬件和 CUDA 同步计时均记录在 `run-metadata.json`。

`raw-motion.npz` 保存 normalized_features、反归一化 features、22 关节坐标、
初始噪声、生成 latent 与文本 embedding。坐标为 HumanML3D 的 Y-up，长度单位米。
SMPL 网格另由官方 SMPLify3D 做 50 次外层 L-BFGS 拟合。生成器推理耗时和
网格拟合耗时分开计量。人体参数模型与 shape blendshapes 不包含在下载材料中。

原作者软件与示例素材属于 Tsinghua University / Shanghai AI Laboratory，
适用附带的 MotionLCM 非商业科研教育许可。适配代码位于博客的
`tools/motion-series/infer-motionlcm.py`、`fit-motionlcm.py`；下载包的 `infer.py`、
`fit.py` 是其独立命令行入口，保留出处与修改记录。

SMPL-Body 用于人体动画，署名 Max Planck Institute for Intelligent Systems。
输出人体网格依照 [SMPL-Body 条款](https://smpl.is.tue.mpg.de/bodylicense.html)
与 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) 共享。
修改包括生成姿态、以中性体型拟合、逐帧盆骨刚体对齐、整段地面平移与显示配色。
这些输出不包含 SMPL 参数模型、shape blendshapes 或模型生成工具。
缓存中的参数模型仅用于非商业教育研究，依照
[SMPL-Model 条款](https://smpl.is.tue.mpg.de/modellicense.html)，不再分发。

来源：

- [MotionLCM 官方仓库](https://github.com/Dai-Wenxun/MotionLCM)
- [固定版本与准备脚本](https://github.com/Dai-Wenxun/MotionLCM/tree/81c06368c17b056713deef2e9f6483f3172eea42)
- [sentence-t5-large 官方文本编码器](https://huggingface.co/sentence-transformers/sentence-t5-large)
- [SMPL: A Skinned Multi-Person Linear Model](https://smpl.is.tue.mpg.de/)
