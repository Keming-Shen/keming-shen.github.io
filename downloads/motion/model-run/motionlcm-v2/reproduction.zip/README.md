# MotionLCM V2：本地动作推理与人体表面拟合

下载包包含已实际运行的原始动作、运行记录、独立适配脚本和许可。两个动作由官方预训练模型生成；`raw-motion.npz` 不是随机初始化示例。权重、文本编码器与 SMPL 参数不在下载包中，由脚本从对应官方资源获取到用户自己的本地目录。

## 1. 固定版本与依赖

- [MotionLCM 官方仓库](https://github.com/Dai-Wenxun/MotionLCM)，commit `81c06368c17b056713deef2e9f6483f3172eea42`。
- MotionLCM **V2** HumanML3D 检查点：`experiments_t2m/motionlcm_humanml/motionlcm_humanml.ckpt`，SHA-256 `19fcd9ccb34850da36bad2563c47df19c5944282e7b87a5447ad1be3b44363d8`。名称带 `_v1` 的文件不用于这次记录。
- [sentence-t5-large](https://huggingface.co/sentence-transformers/sentence-t5-large)，固定 revision `1b36eb48a1df42a07ffd02234d25abfbf3e3f3cb`；完整 SentenceTransformer pooling、Dense 和 Normalize 链均保留。
- 实际环境：Python 3.10.20、PyTorch 2.11.0+cu128、torchvision 0.26.0+cu128、NumPy 1.26.4、RTX 5090 Laptop GPU。其余版本见 `environment.json` 与 `requirements.txt`。

建议在独立 Python 3.10 环境中先安装与本机 CPU/CUDA 平台匹配的 PyTorch 和 torchvision，再安装其余依赖：

```text
python -m pip install -r requirements.txt
```

推理支持 CUDA 或 CPU；当前拟合脚本采用 CUDA。不同硬件和库版本可能产生数值差异，不能据单次记录承诺相同耗时。

## 2. 获取资源

在包含这些脚本的目录中执行：

```text
python prepare_resources.py --repo MotionLCM --stage code
python prepare_resources.py --repo MotionLCM --stage inference
```

第一步将固定源码下载到空的 `MotionLCM/`。第二步使用官方准备脚本同一公开 Drive ID，下载约 714MB 的 T2M 检查点包、约 644KB 的 tiny 数据包，以及固定版本的文本编码器。tiny 数据包中的 `Mean.npy`、`Std.npy` 用于恢复动作坐标。网络资源可能改变或暂时不可用，脚本遇到失败会报告错误；不会用随机权重替代。

仅需要骨架坐标时无需下载 SMPL。需要拟合人体表面时，先阅读 [SMPL-Model 许可](https://smpl.is.tue.mpg.de/modellicense.html)，再单独选择官方人体模型依赖：

```text
python prepare_resources.py --repo MotionLCM --stage body
```

参数只在本机 `MotionLCM/deps/smpl_models/` 中使用，不应放到网站公开下载目录。资源记录留在相邻 `.motionlcm-resource-downloads/`。

## 3. 推理

```text
python infer.py --repo MotionLCM --output run --frames 100 --seed 1234
```

VAE、denoiser、scheduler、文本编码器、guidance embedding 和关节恢复调用官方实现；适配脚本省略训练与评测框架，并 strict 加载模型子模块权重。运行期间读取本地模型，不调用远程推理 API。

两个默认文本为：

- `a person walks forward and turns left.`
- `a person raises their right arm above their head.`

默认 batch=2、100 帧/段、20fps、one-step、timestep=799、guidance=8。帧数范围为 40–200。改变文本时可修改脚本中的 `prompts`；改变样本数也会改变后续噪声排列，不能继续声称输出与提供的记录相同。

`run/inference/` 输出 `motionlcm-v2-raw.npz`、`sample-00/01.pkl`、单独关节 NPY 与 JSON 运行记录。当前包的 `raw-motion.npz` 就是原始已运行记录，对应字段均为 float32：

- `normalized_features`：`[2,100,263]`，归一化后的生成特征。
- `features`：`[2,100,263]`，按官方 Mean/Std 反归一化的特征。
- `joints`：`[2,100,22,3]`，HumanML3D recover_from_ric 恢复的空间关节。
- `initial_noise`、`latents`：`[2,16,32]`。
- `text_embedding`：`[2,1,768]`。

直接分析第一段：

```python
import numpy as np

with np.load("raw-motion.npz", allow_pickle=False) as data:
    joints = data["joints"][0]  # [100, 22, 3]
    root = joints[:, 0]
    print(joints.shape)
    print("根节点首末位移（米）:", root[-1] - root[0])
```

关节坐标为 Y-up、米，包含恢复后的世界根运动。帧间隔 0.05s；100 帧的播放槽长为 5s，首末采样点跨度为 4.95s。原始 `joints` 尚未应用后续网格的地面平移；叠加骨架与表面时，应使用拟合输出同目录的 `sample-NN-joints.npy`，不能把原始坐标与平移后网格直接叠放。

便携推理脚本已在本机实际重复运行，六个 NPZ 字段与原始记录的最大绝对差值均为 0；该检查仅说明这次固定环境的适配脚本一致。

## 4. SMPL 拟合

```text
python fit.py --repo MotionLCM --output run --sample 0 --iterations 50
python fit.py --repo MotionLCM --output run --sample 1 --iterations 50
```

也可用 `--input path/to/motion.pkl` 指定包含 `joints`、`text`、`seed` 的真实生成动作。官方 SMPLify3D 使用 AMASS 22 关节对应、GMM 姿态先验和 L-BFGS。这里采用 50 次外层迭代，官方 `fit.py` 默认是 150。`num_iters` 同时作为内部 L-BFGS 的 `max_iter`，因此不能把 50 简化为“只做50次梯度计算”，耗时也不能线性外推为150的三分之一。

最终以中性零体型得到表面。官方 `transl=root` 留下 SMPL 模板盆骨偏移，适配脚本再作逐帧刚体盆骨对齐和整段地面平移；这一操作不改变姿态和局部表面。输出为 `run/mesh/` 中的：

- `sample-NN-vertices.npy`：float32 `[100,6890,3]`。
- `faces.npy`：uint32 `[13776,3]`，两段共享同一拓扑。
- `sample-NN-joints.npy`：与表面同一地面变换的生成关节。
- `sample-NN-fitted-joints.npy`：实际表面模型的关节。
- `sample-NN-mesh.npz`、`sample-NN-mesh.pkl`、`sample-NN-metadata.json`。

拟合输出仍为 Y-up、米、20fps、地面 Y=0。零体型表面与数据骨架的比例不同，拟合不保证逐点精确或物理执行。两段实际关节误差均值为 2.12cm、3.88cm，后者最大误差为10.19cm；数值定义为盆骨对齐、地面变换后22个关节的欧氏距离。

## 5. 计时范围

原始推理记录的两个样本总生成时间为 0.4256464s，包括文本编码、初始噪声、一步去噪、VAE解码、反归一化与关节恢复，计时边界做了 CUDA 同步。它不包含下载、检查点初读、模型构造、网格拟合、NPZ写盘或渲染。

`initialization_seconds=1.4210992` 记录组件构造、权重装载、文本编码器读取和数据准备；最开始的 `torch.load(checkpoint)` 在此计时之外。两段网格拟合分别为 88.5908s、91.3860s，包含官方优化过程与最终表面计算，不包含模型下载、最终文件写入与渲染。它们是单次本机记录，不是比较不同方法的基准测试。

## 6. 许可、署名与展示格式

MotionLCM 代码与相关资源保留 Tsinghua University / Shanghai AI Laboratory 的署名和附带 `MotionLCM-LICENSE.txt`，限非商业科研教育用途。适配脚本保留官方计算，修改为独立命令行入口、固定本地资源、公开稳定逻辑路径、补充盆骨/地面坐标适配和运行证据。

SMPL-Body 用于人体动画，署名 **Max Planck Institute for Intelligent Systems**。不含参数模型、shape blendshapes 或模型生成工具的生成网格，依照 [SMPL-Body 许可](https://smpl.is.tue.mpg.de/bodylicense.html) 与 [CC BY4.0](https://creativecommons.org/licenses/by/4.0/) 分享，并注明生成姿态、中性体型拟合、盆骨对齐、地面平移、配色等修改。SMPL 参数模型仍依 [SMPL-Model 许可](https://smpl.is.tue.mpg.de/modellicense.html) 留在本机、不再分发。引用 [SMPL: A Skinned Multi-Person Linear Model](https://smpl.is.tue.mpg.de/)。

网页可把纯输出顶点编码为 Uint16 再传输；这一格式变化不把顶点变成模型参数。展示资产应明确记录量化方式、坐标范围、解码尺度与修改说明，并保留上述署名和许可。若每轴采用包围盒归一化并四舍五入，则 `q=round((v-min)/(max-min)*65535)`，解码为 `v=min+q/65535*(max-min)`；每轴理论量化误差不超过对应范围的一半除以65535，不包含浮点运算误差。不要把量化后的显示数据称为原始float32输出。
